package huyhqps09542;

import java.util.Scanner;


public class main {

   
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        QuanLySinhVien qlsv = new QuanLySinhVien();
        while(true)
        {
            Menu(); 
            String so = "";
            do{
            System.out.print("《Xin hãy chọn chức năng➺➺: ");
            so = sc.nextLine();
            }while(!qlsv.isNumber(so, 1) || so.isEmpty()); 
            int n = Integer.parseInt(so);
            ChonChucNang(qlsv, n);
        }
    }
    
    static void Menu()
    {
         System.out.println("  ╓ ________________________________________________╖");
        System.out.println(" ║( ¬‿¬)˛ *.˛*.˛°˛♥Quản Lí Học Viên♥*.°.˛*.˛°˛.( ¬‿¬)║");
        System.out.println("║               01-Nhập Danh Sách Học Viên            ║");
        System.out.println("║               01- Xuất Danh Sách Học Viên           ║");
        System.out.println("║            02-Tìm Học Viên Theo Khoảng Điểm         ║");
        System.out.println("║              03-Tìm Học Viên Theo Học Lực           ║");
        System.out.println("║       04-Tìm Theo Mã Số và Cập Nhật Thông Tin SV    ║");
        System.out.println("║              05-Sắp Xếp Học Viên Theo Điểm          ║");
        System.out.println("║             06- 5 Học Viên Có Điểm Cao Nhất         ║");
        System.out.println("║              07-Điểm Trung Bình Của Cả Lớp          ║");
        System.out.println("║              08-Tìm Học Viên Theo Học Lực           ║");
        System.out.println("║          09-Tổng Hợp Số Học Viên Theo Học Lực       ║");
        System.out.println("║                     ✏  END  ✍                      ║");
        System.out.println("╙ ____________________________________________________╜");
        System.out.println("〖            →   Vui Lòng Chọn Từ 1 Đến 9   ←        〗");
        System.out.println("☞ ☞ Mời Bạn Nhập:");
         // Gọi hàm và tính toán các kiểu
    }
    
    static void ChonChucNang(QuanLySinhVien ql, int a)
    {
        switch (a)
            {
            case 1:
                System.out.println("    ★。* 。*★Kết Quả★ 。* 。*★    ");
                System.out.println("✔Nhập Danh Sách Học Viên✔");
                ql.NhapDS();
                break;
            case 2:
                System.out.println("    ★。* 。*★Kết Quả★ 。* 。*★    ");
                System.out.println("✔Xuất Danh Sách Học Viên✔");
                ql.XuatDS();
                break;
            case 3:
                System.out.println("    ★。* 。*★Kết Quả★ 。* 。*★    ");
                System.out.println("  ✔Tìm Học Viên Theo Khoảng Điểm✔ ");
                ql.TimKiemTheoDiem();
                break;
            case 4:
                System.out.println("    ★。* 。*★Kết Quả★ 。* 。*★    ");
                System.out.println("    ✔Tìm Học Viên Theo Học Lực✔   ");
                ql.TimKiemTheoHocLuc();
                break;
            case 5:
                 System.out.println("    ★。* 。*★Kết Quả★ 。* 。*★    ");
                System.out.println("✔Tìm Theo Mã Số và Cập Nhật Thông Tin SV✔");
                ql.TimKiemTheoMa();
                break;
            case 6:
                System.out.println("    ★。* 。*★Kết Quả★ 。* 。*★    ");
                System.out.println("    ✔Sắp Xếp Học Viên Theo Điểm✔  ");
                ql.SapXepTheoDiem();
                break;
            case 7:
                System.out.println("    ★。* 。*★Kết Quả★ 。* 。*★    ");
                System.out.println("    ✔5 Học Viên Có Điểm Cao Nhất✔ ");
                ql.XuatTop5SV();
                break;
            case 8:
                System.out.println("    ★。* 。*★Kết Quả★ 。* 。*★    ");
                System.out.println("    ✔Điểm Trung Bình Của Cả Lớp✔  ");
                ql.DTBLop();
                break;
            case 9:
                System.out.println("    ★。* 。*★Kết Quả★ 。* 。*★    ");
                System.out.println("    ✔Tìm Học Viên Theo Học Lực✔  ");
                ql.XuatDSSV_Hon_DTBLop();;
                break;
            case 10:
                 System.out.println("    ★。* 。*★Kết Quả★ 。* 。*★    ");
                System.out.println("✔Tổng Hợp Số Học Viên Theo Học Lực✔");
                ql.XuatSVTheoHocLuc();
                break;
            case 0:
                //ql.LayHoTen();
                System.exit(0);
                break;
            default:
                System.out.println("Nhập sai rồi!");
            }
    }
}
