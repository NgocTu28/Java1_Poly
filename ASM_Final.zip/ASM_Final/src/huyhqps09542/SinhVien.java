
package huyhqps09542;

import java.util.Scanner;

/**
 *
 * @author ANNPRO
 */
public class SinhVien {
    Scanner sc = new Scanner(System.in);
    // Khai báo biến
    private String _masv = "";
    private String _hoten = "";
    private double _diem = 0d;
    private String _email = "";
    private String _hocluc = "";
    
    // Hàm khởi tạo
    public SinhVien()
    {
        
    }
    
    public SinhVien(String masv, String hoten, double diem, String email, String hocluc)
    {
        this._masv = masv;
        this._hoten = hoten;
        this._diem = diem;
        this._email = email;
        this._hocluc = hocluc;
    }
    
    //get set mã sinh viên
    public String GetMaSV()
    {
        return _masv;
    }
    
    public void SetMaSV(String masv)
    {
        _masv = masv;
    }
    
    // Get set hoten
    public String GetHoTen()
    {
        return _hoten;
    }
    
    public void SetHoTen(String hoten)
    {
        _hoten = hoten;
    }
    
    // Get Set diem
    public double GetDiem()
    {
        return _diem;
    }
    
    public void SetDiem(double diem)
    {
        _diem = diem;
    }
    
    // Get set email
    public String GetEmail()
    {
        return _email;
    }
    
    public void SetEmail(String email)
    {
        _email = email;
    }
        
    // Get Set học lực
    public String GetHocLuc()
    {
        return _hocluc;
    }
    
    public void SetHocLuc(String hocluc)
    {
        _hocluc = hocluc;
    }
    
    // Xếp loại học lực
    public String XepLoaiHL(double diem)
    {
        if (diem >= 9)
        {
            SetHocLuc("Xuất sắc");
        }
        else if (diem >= 7.5)
        {
            SetHocLuc("Giỏi");
        }
        else if (diem >= 6.5)
        {
            SetHocLuc("Khá");
        }
        else if (diem >= 5)
        {
            SetHocLuc("Trung bình");
        }
        else if (diem < 5)
        {
            SetHocLuc("Yếu");
        }
        return GetHocLuc();
    }
    
    // Xuat sinh viên
    public void Xuat()
    {
        System.out.println("MaSV: " + GetMaSV());
        System.out.println("Họ tên: " + GetHoTen());
        System.out.println("Điểm: " + GetDiem());
        System.out.println("Email: " + GetEmail());
        System.out.println("Học lực: " + GetHocLuc());
        System.out.println("------------------------------------------------");
    }
    
    public void TestMail()
    {

        String test_email = "^[\\w-_\\.[^0-9]]+\\@[\\w&&[a-z][^0-9]]+\\.[\\w&&[a-z][^0-9]]+[\\.[a-z]]+$";
        
        while(!GetEmail().matches(test_email))
        {
            System.out.println("Email không đúng định dạng!");
            System.out.print("Nhập lại email: ");
            SetEmail(sc.nextLine());
        }
    }
}








