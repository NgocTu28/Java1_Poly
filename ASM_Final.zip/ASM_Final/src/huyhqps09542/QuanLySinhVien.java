
package huyhqps09542;

import java.util.Scanner;
import java.util.ArrayList;


public class QuanLySinhVien {
    Scanner sc = new Scanner(System.in);
    ArrayList<SinhVien> arrSV = new ArrayList<>();
    
    // YC1: Nhập danh sách sinh viên. 
    public void NhapDS()
    {
        String so = "";
        do{
            System.out.print("Số Lượng sinh viên bạn muốn nhập là ⇒ ⇒: ");
            so = sc.nextLine();
        }while(!isNumber(so, 1) || so.isEmpty());
        int sopt = Integer.parseInt(so);
        System.out.println("------------------------------------------------");
        
        for(int i = 0; i < sopt; i++)
        {
            String _ma = "";
            String _hoten = "";
            double _diem = 0d;
            String _email = "";
            
            System.out.println("Nhập sinh viên Đầu tiên :");
            SinhVien sv1 = new SinhVien();
            
            do{
                 System.out.print("");
                System.out.print("Nhập mã sinh viên: ");
                _ma = sc.nextLine();
            }while(KT_TrungMa(_ma) == true);
            
            do{
                System.out.print("nhập họ và tên: ");
                _hoten = sc.nextLine();
            }while(_hoten.isEmpty() || KT_TrungTen(_hoten) == true);
            
            String diem_tam = "";
            do{
                System.out.print("Nhập điểm 0 -> 10: ");
                diem_tam = sc.nextLine();
            }while(!isNumber(diem_tam, 2) || diem_tam.isEmpty());
            _diem = Double.parseDouble(diem_tam);

            while(_diem < 0 || _diem > 10)
            {
                System.out.print("Nhập điểm 0 -> 10: ");
                _diem = sc.nextDouble();
            }
            
            do{
                System.out.print("Nhập email: ");
                _email = sc.nextLine();
            }while(TestMail(_email) == true);

            SinhVien sv = new SinhVien(_ma, _hoten, _diem, _email, sv1.XepLoaiHL(_diem));
            arrSV.add(sv);
            
            System.out.println("------------------------------------------------");
        }
    }
    
    // YC2: Xuất danh sách sinh viên. 
    public void XuatDS()
    {
        KT_Data_Nhap();
        System.out.println("------------------------------------------------");
        for(int i = 0; i < arrSV.size(); i++)
        {
            arrSV.get(i).Xuat();
        }
    }
    
    //YC3: Tìm kiếm sinh viên theo điểm.
    public void TimKiemTheoDiem()
    {
        KT_Data_Nhap();
        if (arrSV.size() != 0)
        {
            int dem = 0;
            double diem = 0d;
            do{
                System.out.print("Nhập điểm cần tìm 0 -> 10: ");
            diem = sc.nextDouble();
            }while(diem < 0 || diem > 10);
            System.out.println("------------------------------------------------");
            for(int i = 0; i < arrSV.size(); i++)
            {
                if(arrSV.get(i).GetDiem() == diem)
                {
                    dem++;
                    arrSV.get(i).Xuat();
                }
            }
            if (dem == 0)
                System.out.println("Không tìm thấy điểm " + diem + " vừa nhập.");
        }
    }
    
    //YC4: Tìm kiếm sinh viên theo học lực.
    public void TimKiemTheoHocLuc()
    {
        //System.out.println("------------------------------------------------");
        KT_Data_Nhap();
        if (arrSV.size() != 0)
        {
            int dem = 0;
            System.out.print("VD: xuất sắc, giỏi, khá,...\n");
            System.out.print("Nhập học lực cần tìm: ");
            String hocluc = sc.nextLine();
            System.out.println("------------------------------------------------");
            for(int i = 0; i < arrSV.size(); i++)
            {
                if(arrSV.get(i).GetHocLuc().equalsIgnoreCase(hocluc))
                {
                    dem++;
                    arrSV.get(i).Xuat();
                }
            }
            if (dem == 0)
                System.out.println("Không tìm thấy học lực " + hocluc + " vừa nhập.");
        }
    }
    
    // YC5: Tìm học viên theo mã số.  
    public void TimKiemTheoMa()
    {
        KT_Data_Nhap();
        if (arrSV.size() != 0)
        {
            System.out.println("------------------------------------------------");
            int dem = 0;
            System.out.print("VD: SV1, SV2, SV3,...\n");
            System.out.print("Nhập mã sinh viên cần tìm: ");
            String masv = sc.nextLine();
            System.out.println("------------------------------------------------");
            for(int i = 0; i < arrSV.size(); i++)
            {
                if(arrSV.get(i).GetMaSV().equalsIgnoreCase(masv))
                {
                    dem++;
                    arrSV.get(i).Xuat();
                }
            }
            if (dem == 0)
                System.out.println("Không tìm thấy mã sinh viên " + masv + " vừa nhập.");
        }
    }
    
    SinhVien tam = new SinhVien();
    void Sort()
    {
        for(int i = 0; i < arrSV.size(); i++)
        {
            for(int j = i + 1; j < arrSV.size(); j++)
            {
                if (arrSV.get(i).GetDiem() > arrSV.get(j).GetDiem())
                {
                    tam = arrSV.get(i);
                    arrSV.set(i, arrSV.get(j));
                    arrSV.set(j, tam);
                }
            }
        }
    }
    
    //YC6: Sắp xếp sinh viên theo điểm. 
    public void SapXepTheoDiem()
    {
        KT_Data_Nhap();
        if (arrSV.size() != 0)
        {
            System.out.println("------------------------------------------------");
            Sort();
            System.out.println("Điểm sau khi sắp xếp.");
            XuatDS();
        }
    }
    
    //YC7: Xuất 5 sinh viên điểm cao nhất.
    public void XuatTop5SV()
    {
        KT_Data_Nhap();
        System.out.println("------------------------------------------------");
        Sort();
        int dem = 0;
        for(int i = arrSV.size() - 1; i >= 0; i--)
        {
            arrSV.get(i).Xuat();
            dem++;
            if (dem == 5)
            {
                break;
            }
        }
    }
    
    double tong = 0d;
    int dem = 0;
    void XetDiem()
    {
        for(int i = 0; i < arrSV.size(); i++)
        {
            tong += arrSV.get(i).GetDiem();
            dem++;
        }
        System.out.println("Điểm trung bình cả lớp là " + (tong / dem));
    }
    
    //YC8: Điểm trung bình của lớp.
    public void DTBLop()
    {
        KT_Data_Nhap();
        if (arrSV.size() != 0)
        {
            XetDiem();
        }
    }
    
    //YC9: Xuất danh sách học viên cao hơn ĐTB lớp.
    public void XuatDSSV_Hon_DTBLop()
    {
        KT_Data_Nhap();
        if (arrSV.size() != 0)
        {
            XetDiem();
            for(int j = 0; j < arrSV.size(); j++)
            {
                if (arrSV.get(j).GetDiem() > (tong / dem ))
                {
                    arrSV.get(j).Xuat();
                }
            }
        }
    }
    
    //YC10: Tổng hợp học viên theo học lực.
    public void XuatSVTheoHocLuc()
    {
        KT_Data_Nhap();
        if (arrSV.size() != 0)
        {
            int dem = 0;
            System.out.print("VD: xuất sắc, giỏi, khá,...\n");
            System.out.print("Nhập học lực sinh viên: ");
            String hocluc = sc.nextLine();
            System.out.println("------------------------------------------------");
            for (int i = 0; i < arrSV.size(); i++)
            {
                if (arrSV.get(i).GetHocLuc().equalsIgnoreCase(hocluc))
                {
                    dem++;
                    arrSV.get(i).Xuat();
                }
            }
            if (dem == 0)
                System.out.println("Không tìm thấy học lực " + hocluc + " vừa nhập.");
        }
    }
    
    // Kiểm tra số
    public boolean isNumber(String str, int n)
    {
        if (n == 1)
        {
            for (int i = 0; i < str.length(); i++) 
            {
                if (!Character.isDigit(str.charAt(i))) 
                {
                    return false;
                }
            }
        }
        else
        {
            for (int i = 0; i < str.length(); i++) 
            {
                if (!Character.isDigit(str.charAt(i))) 
                {
                    return false;
                }
                else
                    return true;
            }
        }
        return true;
    }
    
    void KT_Data_Nhap()
    {
        if (arrSV.size() == 0)
        {
            System.out.println("Vui lòng nhập dữ liệu. Xin cám ơn!");
        }
    }
    
    public boolean KT_TrungMa(String ma)
    {
        for(int i = 0; i < arrSV.size(); i++)
        {
           if (ma.equalsIgnoreCase(arrSV.get(i).GetMaSV()) == true)
           {
               return true;
           }
        }
        return false;
    }
       
    public boolean KT_TrungTen(String hoten)
    {
        for(int i = 0; i < arrSV.size(); i++)
        {
           if (hoten.equalsIgnoreCase(arrSV.get(i).GetHoTen()) == true)
           {
               return true;
           }
        }
        return false;
    }
    
    public boolean TestMail(String email)
    {
        String test_email = "^[\\w-_\\.[^0-9]]+\\@[\\w&&[a-z][^0-9]]+\\.[\\w&&[a-z][^0-9]]+[\\.[a-z]]+$";
        
        while(!email.matches(test_email))
        {
            return true;
        }
        return false;
    }
}